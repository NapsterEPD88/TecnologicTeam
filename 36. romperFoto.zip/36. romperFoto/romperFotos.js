window.onload=iniciar;

function iniciar(){

	console.log(document.querySelector("#trozo2").offsetLeft);

document.querySelector("#trozo2").onclick=pasarPagina;



}

function pasarPagina(event){
	event.currentTarget.style.animation="pasarPag 3s linear";
	document.querySelector("#trozo3").style.animation="pasarPag2 3s linear";
	/*event.currentTarget.style.transform="rotateY(180deg)";
	 var posicionx=document.querySelector("#derecha").offsetLeft; 
    var izquierda = document.querySelector("#derecha").style.left=(posicionx  - 500)+"px";*/
    

}