window.onload=init;

function init(){
	//document.getElementsByTagName("button")[0].onclick=ampliar;
	document.querySelector("button").onclick=ampliar;
}

function ampliar(event){
	var parrafo=document.querySelector("p:last-of-type");
	
	if (parrafo.style.display=="none" || parrafo.style.display==""){
		parrafo.style.display="block";
		event.currentTarget.innerHTML="<< Reducir";
	}
	else{
		parrafo.style.display="none";
		event.currentTarget.innerHTML="Leer más >>";
	}
}