window.onload=init;

function init(){
	document.forms[0].provincia.onchange=rellenarMunicipios;
	rellenar(document.forms[0].provincia,["Madrid","Córdoba"]);
}

function rellenarMunicipios(event){
	var municipiosCS=["Vila-real","Castellón","Burriana"];
	var municipiosVL=["Valencia","Paterna","Manises"];
	var municipiosAL=["Alcoi","Alicante","Sax"];

	var seleccion=event.currentTarget.options[event.currentTarget.selectedIndex].value;


	var selectRellenar=document.forms[0].municipio;
	selectRellenar.innerHTML="";

	if (seleccion==="1"){
		rellenar(selectRellenar,municipiosCS);
	}
	else if (seleccion==="2"){
		rellenar(selectRellenar,municipiosVL);
	}
	else if (seleccion==="3"){
		rellenar(selectRellenar,municipiosAL);
	}
	else{
		selectRellenar.disabled=true;
	}

	
}

function rellenar(lista,municipios){
	var opcion=null;
		
	for (var i = 0; i < municipios.length; i++) {
		opcion=document.createElement("option");
		opcion.value=i;
		opcion.text=municipios[i];
		lista.appendChild(opcion);
	}
	lista.disabled=false;
}