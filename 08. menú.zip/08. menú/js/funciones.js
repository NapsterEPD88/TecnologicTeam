window.onload=init;
var menuDesplegado=null;

function init(){
	var objetos=document.querySelectorAll("li>ul");
	for(var i=0;i<objetos.length;i++){
		objetos[i].parentNode.onclick=desplegar;
	}
}

function desplegar(){
	if (menuDesplegado!=null){
		menuDesplegado.style.display="none";
	}
	if (menuDesplegado==event.currentTarget.childNodes[1]){
		menuDesplegado=null;
	}
	else{
		event.currentTarget.childNodes[1].style.display="block";
		menuDesplegado=event.currentTarget.childNodes[1];
	}
}