window.onload=init;
var posiciones=[];
function init(){
	var contenedor=document.querySelector("#contenedor");
	//tamanyo del contenedor
	var anchuraContenedor=contenedor.offsetWidth;
	var alturaContenedor=contenedor.offsetHeight;

	var alturaCuadrado=alturaContenedor/10;
	var anchuraCuadrado=anchuraContenedor/10;

	var imagen=document.querySelector("#contenedor>img:last-child");
	imagen.style.display="none";
	
	var cuadrado;
	
	for (var j=0;j<10;j++){
		for (var i=0;i<10;i++){
		posiciones[i+j*10]=i+j*10;
		cuadrado=document.createElement("div");
		cuadrado.id="c"+(i+j*10);
		cuadrado.style.top=(j*alturaCuadrado)+"px";
		cuadrado.style.left=(i*anchuraCuadrado)+"px";
		cuadrado.style.width=anchuraCuadrado+"px";
		cuadrado.style.height=alturaCuadrado+"px";
		cuadrado.style.backgroundImage="url("+imagen.src+")";
		cuadrado.style.backgroundSize="500px 500px";
		cuadrado.style.backgroundPosition="-"+(i*anchuraCuadrado)+"px -"+(j*alturaCuadrado)+"px";
		cuadrado.onclick=animar;
		contenedor.appendChild(cuadrado);
		}
	}




	/*cuadrado=document.createElement("div");
	cuadrado.style.top="0px";
	cuadrado.style.left="100px";
	cuadrado.style.width="100px";
	cuadrado.style.height="100px";
	cuadrado.style.backgroundImage="url("+imagen.src+")";
	cuadrado.style.backgroundSize="500px 500px";
	cuadrado.style.backgroundPosition="-100px 0px";
	contenedor.appendChild(cuadrado);

	cuadrado=document.createElement("div");
	cuadrado.style.top="0px";
	cuadrado.style.left="200px";
	cuadrado.style.width="100px";
	cuadrado.style.height="100px";
	cuadrado.style.backgroundImage="url(img/escudo.png)";
	cuadrado.style.backgroundSize="500px 500px";
	cuadrado.style.backgroundPosition="-200px 0px";
	contenedor.appendChild(cuadrado);
	
	cuadrado=document.createElement("div");
	cuadrado.style.top="0px";
	cuadrado.style.left="300px";
	cuadrado.style.width="100px";
	cuadrado.style.height="100px";
	cuadrado.style.backgroundImage="url(img/escudo.png)";
	cuadrado.style.backgroundSize="500px 500px";
	cuadrado.style.backgroundPosition="-300px 0px";
	contenedor.appendChild(cuadrado);

	cuadrado=document.createElement("div");
	cuadrado.style.top="0px";
	cuadrado.style.left="400px";
	cuadrado.style.width="100px";
	cuadrado.style.height="100px";
	cuadrado.style.backgroundImage="url(img/escudo.png)";
	cuadrado.style.backgroundSize="500px 500px";
	cuadrado.style.backgroundPosition="-400px 0px";
	contenedor.appendChild(cuadrado);*/	

}

function animar(event){
	var aleatorio=0;
	var aleatorio2=0;
	var objeto=null;
	while (posiciones.length>0){
		aleatorio=Math.floor(Math.random()*posiciones.length);
		objeto=document.querySelector("#c"+posiciones[aleatorio]);

		aleatorio2=Math.floor(Math.random()*10)+1;
		objeto.style.transitionDelay=(aleatorio2*200)+"ms";
		objeto.style.transitionDuration=(500+aleatorio2*200)+"ms";
		objeto.style.opacity="0";
		posiciones.splice(aleatorio,1);
	}
}