var preguntas=[{
	pregunta: "¿Quién soy?",
	respuestas:[
		{texto: "El profesor",correcta: false},
		{texto: "El alumno",correcta: false},
		{texto: "Dios",correcta: true}
	]
},
{
	pregunta: "¿Cómo me llamo?",
	respuestas:[
		{texto: "Juan",correcta: false},
		{texto: "Alex",correcta: true},
		{texto: "Pepe",correcta: false}
	]
},
{
	pregunta: "¿De qué equipo soy?",
	respuestas:[
		{texto: "FCBarcelona",correcta: false},
		{texto: "Real Madrid CF",correcta: true},
		{texto: "Villarreal CF",correcta: false}
	]
}
]

window.onload=init;
var aleatorio;
var numPreguntas=0;
var aciertos=0;

function init(){
	document.querySelector("#comprobar").onclick=comprobarRespuesta;
	document.querySelector("#siguiente").onclick=hacerPregunta;
	hacerPregunta();
}

function hacerPregunta(event){
	numPreguntas++;
	var panel=document.querySelector("#panel");
	panel.innerHTML="";

	aleatorio=Math.floor(Math.random()*preguntas.length);
	var objeto=document.createElement("p");
	
	objeto.innerHTML=preguntas[aleatorio].pregunta;
	panel.appendChild(objeto);

	var etiqueta=null;
	var texto=null;
	for (var i = 0; i < preguntas[aleatorio].respuestas.length; i++) {
		etiqueta=document.createElement("label");
		objeto=document.createElement("input");
		objeto.type="radio";
		objeto.name="respuestas";
		objeto.id=i;
		objeto.value=preguntas[aleatorio].respuestas[i].texto;
		texto=document.createTextNode(preguntas[aleatorio].respuestas[i].texto);
		etiqueta.appendChild(objeto);
		etiqueta.appendChild(texto);

		panel.appendChild(etiqueta);
	}	

	document.querySelector("#comprobar").disabled=false;	
	document.querySelector("#siguiente").disabled=true;	
}


function comprobarRespuesta(event){
	var respuestas=document.querySelectorAll("input[name=respuestas]");
	for (var i = 0; i < respuestas.length; i++) {
		if (respuestas[i].checked){
			if (preguntas[aleatorio].respuestas[i].correcta){
				aciertos++;
				alert("acertaste: aciertos "+aciertos+"/"+numPreguntas);
			}
			else{
				alert("fallaste: aciertos "+aciertos+"/"+numPreguntas);
			}
			preguntas.splice(aleatorio,1);
			event.currentTarget.disabled=true;
			document.querySelector("#siguiente").disabled=false;
			break;
		}
	}
}