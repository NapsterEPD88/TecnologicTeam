window.onload=init;

var posicionImagen=1;
var totalImagenes;
//var posicionImagen=0;

function init(){
	document.querySelector("#pie>p").innerHTML+="Javier G. Nieto";
	var icono=document.createElement("img");
	icono.src="img/twitter.png";
	document.querySelector("#redes>a:first-child").appendChild(icono);
	var icono2=document.createElement("img");
	icono2.src="img/face.png";
	document.querySelector("#redes>a:last-child").appendChild(icono2);

	var imagenes=document.querySelectorAll("#imagenes>img");
	totalImagenes=imagenes.length;
	for (var i = 0; i < imagenes.length; i++) {
		if (i!=0){
			imagenes[i].style.display="none";
		}
		imagenes[i].onclick=mostrarNombre;
	}

	var flechas=document.querySelectorAll(".flechas");
	for (var i = 0; i < flechas.length; i++) {
		flechas[i].onmouseenter=function(){
			this.classList.add("activo");
		}
		flechas[i].onmouseleave=function(){
			this.classList.remove("activo");
		}		
	}

	document.querySelector("#derecha").onclick=siguiente;
	document.querySelector("#izquierda").onclick=anterior;

/*	document.querySelector("#derecha").onmouseenter=function(){this.classList.add("activo")};
	document.querySelector("#izquierda").onmouseenter=function(){this.classList.add("activo")};
	document.querySelector("#derecha").onmouseleave=function(){this.classList.remove("activo")};
	document.querySelector("#izquierda").onmouseleave=function(){this.classList.remove("activo")};
*/		
}

function mostrarNombre(event){
	document.querySelector("#nombre>p").innerHTML=event.currentTarget.alt;
}

function siguiente(event){
	if (posicionImagen<totalImagenes){
		document.querySelector("#imagenes>img:nth-child("+ posicionImagen +")").style.display="none";
		posicionImagen++;
		document.querySelector("#imagenes>img:nth-child("+posicionImagen+")").style.display="block";
		document.querySelector("#nombre>p").innerHTML="";
	}	
	/*var imagenes=document.querySelectorAll("#imagenes>img");
	imagenes[posicionImagen].style.display="none";
	posicionImagen++;
	imagenes[posicionImagen].style.display="block";
	*/
	if (posicionImagen==totalImagenes){
		document.querySelector("#derecha").style.visibility="hidden";
	}	
}

function anterior(event){
	if (posicionImagen>1){
		document.querySelector("#imagenes>img:nth-child("+ posicionImagen +")").style.display="none";
		posicionImagen--;
		document.querySelector("#imagenes>img:nth-child("+posicionImagen+")").style.display="block";
		document.querySelector("#nombre>p").innerHTML="";
	}
	if (posicionImagen==1){
		document.querySelector("#izquierda").style.visibility="hidden";
	}
}