window.onload=iniciar;
var imagenMostrada=1;
var totalImagenes=0;

function iniciar(){
	var imagenes=document.querySelectorAll("#imagenes>img");
	totalImagenes=imagenes.length;
	for (var i=0;i<imagenes.length;i++){
		imagenes[i].onclick=mostrarNombre;
		if (i!=0){
			imagenes[i].style.display="none";
		}
	}

	document.querySelector("#pie>p").innerHTML+="Javier G. Nieto";


	document.querySelector("#derecha").onmouseenter=function(){
		this.classList.add("activo");
	};
	document.querySelector("#izquierda").onmouseenter=function(){
		this.classList.add("activo");
	};
	document.querySelector("#derecha").onmouseleave=function(){
		this.classList.remove("activo");
	};
	document.querySelector("#izquierda").onmouseleave=function(){
		this.classList.remove("activo");
	};
	document.querySelector("#izquierda").style.visibility="hidden";
	document.querySelector("#derecha").onclick=cambiarImagen;
	document.querySelector("#izquierda").onclick=cambiarImagen2;

}

function mostrarNombre(event){
	document.querySelector("#nombre>p").innerHTML=event.currentTarget.alt;
}


function cambiarImagen(){
	if (imagenMostrada<totalImagenes){	
		document.querySelector("#imagenes>img:nth-child("+imagenMostrada+")").style.display="none";
		imagenMostrada++;
		document.querySelector("#imagenes>img:nth-child("+imagenMostrada+")").style.display="block";
		document.querySelector("#nombre>p").innerHTML="";
		if (imagenMostrada==totalImagenes){
			document.querySelector("#derecha").style.visibility="hidden";		
		}
		if (imagenMostrada>1){
			document.querySelector("#izquierda").style.visibility="visible";		
		}		
	}	
}

function cambiarImagen2(){
	if (imagenMostrada>1){
		document.querySelector("#imagenes>img:nth-child("+imagenMostrada+")").style.display="none";
		imagenMostrada--;
		document.querySelector("#imagenes>img:nth-child("+imagenMostrada+")").style.display="block";
		document.querySelector("#nombre>p").innerHTML="";
		if (imagenMostrada==1){
			document.querySelector("#izquierda").style.visibility="hidden";		
		}
		if (imagenMostrada>1){
			document.querySelector("#derecha").style.visibility="visible";		
		}	
	}
}