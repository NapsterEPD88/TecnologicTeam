window.onload=iniciar;
var x=0;
var y=0;
var colores=["red","blue","white","yellow"];
var disparos=0;

function iniciar(){
	document.onkeyup=desplazar;
	y=document.querySelector("div#munyeco").offsetTop;
	x=Math.round((document.querySelector("div#pantalla").clientWidth-document.querySelector("div#munyeco").clientWidth)/2);
	document.querySelector("div#munyeco").style.left=x+"px";
	document.querySelector("div#munyeco").style.transition="3s left linear";
}


function desplazar(event){
	var caja=document.querySelector("div#munyeco");
	var tecla=event.keyCode || event.wich;

	switch (tecla){
		case 37:
			x=0;	
		break;
		case 39:
			x=document.querySelector("div#pantalla").clientWidth-caja.offsetWidth;
		break;
		case 32:
			var disparo = document.createElement("div");
			disparos++;
			document.querySelector("span").innerHTML=disparos;
			disparo.classList.add("disparo");
			disparo.style.backgroundColor=colores[disparos%colores.length];
			disparo.style.top=y+"px";
			disparo.addEventListener("transitionend",function(){
				this.parentElement.removeChild(this);
			})
			document.querySelector("div#pantalla").appendChild(disparo);
			var coordenadaDisparoX=caja.offsetLeft+Math.round(caja.offsetWidth/2);
			disparo.style.left=coordenadaDisparoX+"px";
			disparo.style.top="0px";	
	
		break;
	}

	caja.style.left=x+"px";
}