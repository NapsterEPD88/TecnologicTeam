window.onload=iniciar;

function iniciar(){
	var imagenes=document.querySelectorAll("#galeria>img");
	for (var i=0;i<imagenes.length;i++){
		imagenes[i].onclick=mostrarModal;
	}
	window.onresize=ponerBoton;

	document.querySelector("#cerrar").onclick=cerrarModal;
}


function mostrarModal(event){
	document.getElementById("texto").innerHTML=event.currentTarget.alt;
	var foto=document.getElementById("foto");
	foto.src=event.currentTarget.src;
	
	document.getElementById("modal").style.display="block"; 
	
	ponerBoton();

}


function cerrarModal(event){
	document.getElementById("modal").style.display="none";
}		


function ponerBoton(){
	var foto=document.getElementById("foto");
	var botonCerrar=document.querySelector("#cerrar");
	var posicionCerrar=foto.offsetWidth+foto.offsetLeft-botonCerrar.offsetWidth-8;
	botonCerrar.style.left=posicionCerrar+"px";
	botonCerrar.style.top="8px";	
}