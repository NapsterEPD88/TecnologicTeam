window.onload=iniciar;

function iniciar(){
	document.onclick=desplazar;
}

function desplazar(event){
	var x=event.clientX;
	var y=event.clientY;

	var caja=document.querySelector("div");

	caja.style.top=y+"px";
	caja.style.left=x+"px";
}