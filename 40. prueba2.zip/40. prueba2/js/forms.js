window.onload = init;
var casillasMarcadas = 0;

var comarcasCS = ["Alacalaten","Alto Maestrazo","Alto Mijares","Alto Palancia","Bajo Maestrazgo","Los Puertos de Morella","Plana Alta","Plana Baja"];
var comarcasAL = ["Alto Vinalopo","Bajo Vinalopo","Campo de Alicante","Marina Alta","Marina Baja","Vega Baja del Segura","Vinalopo Medio"];
var comarcasVL = ["Campo de Turia","Huerta Norte","Huerta Oeste","Huerta Sur","Mun.la.comarca.La Safor","Rincon de Ademuz"];
/*
	 POBLACION
	 PROVINCIA
	 CP en funcion de la provincia


		 En funcion de la provincia
	 COMARCA
*/
function init() {
	document.forms[0].nombre.onblur = ponerMayusculas;
	document.forms[0].apellidos.onblur = ponerMayusculas;
	document.forms[0].email.onblur = validarEmail;
	document.forms[0].provincia.onchange = cambiarCP;
	document.forms[0].pass.onblur = validarContrasenya;
	document.forms[0].pass_2.onblur = validarContrasenya;
	document.forms[0].dni.onblur = comprobarDNI;
	var casillas = document.forms[0].querySelectorAll("#preferencias input[type=checkbox]");
	for (var i = 0; i < casillas.length; i++) {
		casillas[i].onclick = comprobarPreferencias;
	}
	document.forms[0].terminos.onclick = ponerBotonActivo;
}


function ponerMayusculas(event) {
	var texto = event.currentTarget.value;
	var palabras = texto.split(" ");
	for (var i = 0; i < palabras.length; i++) {
		palabras[i] = palabras[i].charAt(0).toUpperCase() + palabras[i].substring(1).toLowerCase();
	}
	texto = palabras.join(" ");
	event.currentTarget.value = texto;
	ponerBotonActivo();
}

function validarContrasenya(event) {
	var campo = event.currentTarget;
	var expresion;
	var campoError = null;

	expresion = new RegExp(campo.pattern);

	campoError = document.querySelector("[name=" + campo.name + "]~.error");

	//mensaje para si cumple patrón
	if (expresion.test(campo.value) == false) {
		if (campoError.innerHTML == "") {
			campoError.innerHTML = campo.title;
			console.log(campo.title);
		}
	}
	else {
		campoError.innerHTML = "";
	}

	//mensaje si no son iguales las contraseñas
	if (document.forms[0].pass.value != document.forms[0].pass_2.value) {
		if (campoError.innerHTML == "") {
			campoError.innerHTML = "Las contraseñas no coinciden";
		}
	}
	else {
		if (campoError.innerHTML == "Las contraseñas no coinciden") {
			campoError.innerHTML = "";
		}
	}
	ponerBotonActivo();
}

function validarEmail(event) {
	var campo = event.currentTarget;
	var expression = new RegExp(campo.pattern);
	console.log("Entra en validar email");

	campoError = document.querySelector("[name=" + campo.name + "]~.error");

	if (expression.test(campo.value)) {
		console.log("email valido");
		campoError.innerHTML = "";
	} else {
		console.log("email no valido");
		if (campoError.innerHTML == "") {
			campoError.innerHTML = "Email no valido";
		}
	}
	ponerBotonActivo();

}

function cambiarCP(){
	var indice = this.options.selectedIndex;
	var comarcas = document.querySelector("#comarca");
	var texto;
	var opcion;
	console.log(indice);

	var campoError = document.querySelector("[name=" + this.name + "]~.error");

	switch(indice){
		case 0: {
			document.forms[0].cp.value="";
			campoError.innerHTML = "Selecciona provincia";
			comarcas.innerHTML = "";
			break;
		}
		case 1: {
			document.forms[0].cp.value="03";
			campoError.innerHTML = "";
			comarcas.innerHTML = "";

			for(var i = 0; i < comarcasAL.length;i++){
				texto = comarcasAL[i];
				opcion = document.createElement("option");
				opcion.text = texto;
				opcion.value = i;
				comarcas.appendChild(opcion);
			}
			break;
		}
		case 2: {
			document.forms[0].cp.value="12";
			campoError.innerHTML = "";
			comarcas.innerHTML = "";

			for(var i = 0; i < comarcasCS.length;i++){
				texto = comarcasCS[i];
				opcion = document.createElement("option");
				opcion.text = texto;
				opcion.value = i;
				comarcas.appendChild(opcion);
			}
			break;
		}
		case 3: {
			document.forms[0].cp.value="46";
			campoError.innerHTML = "";
			comarcas.innerHTML = "";

			for(var i = 0; i < comarcasVL.length;i++){
				texto = comarcasVL[i];
				opcion = document.createElement("option");
				opcion.text = texto;
				opcion.value = i;
				comarcas.appendChild(opcion);
			}
			break;
		}
		default: {
			document.forms[0].cp.value="";
			campoError.innerHTML = "Selecciona provincia";
			comarcas.innerHTML = "";
		}
	}
	ponerBotonActivo();

}

function comprobarPreferencias(event) {
	if (event.currentTarget.checked) {
		casillasMarcadas++;
	}
	else {
		casillasMarcadas--;
	}


	if (casillasMarcadas == 3) {
		var af = document.forms[0].querySelectorAll("#preferencias input[type=checkbox]:not(:checked)");
		for (var i = 0; i < af.length; i++) {
			af[i].disabled = true;
		}
	}
	else {
		var af = document.forms[0].querySelectorAll("#preferencias input[type=checkbox]:disabled");
		for (var i = 0; i < af.length; i++) {
			af[i].disabled = false;
		}
	}

	ponerBotonActivo();
}

function ponerBotonActivo(event) {
	var error = false;

	var campos = document.forms[0].querySelectorAll("[required]");

	var campoError = null;
	for (var i = 0; i < campos.length; i++) {
		campoError = document.querySelector("[name=" + campos[i].name + "]~.error");
		if (campos[i].value == "") {
			error = true;
			campoError.innerHTML = "El campo no puede estar vacío";
		}
		else {
			if (campoError.innerHTML == "El campo no puede estar vacío") {
				campoError.innerHTML = "";
			}
		}
	}

	if (casillasMarcadas == 0) {
		error = true;
	}

	if (!document.forms[0].terminos.checked) {
		error = true;
	}

	if (!error) {
		document.forms[0].enviar.disabled = false;
	}
	else {
		document.forms[0].enviar.disabled = true;
	}

	if(!document.querySelector("#provincia").options.selectedIndex) {
		document.querySelector("#provincia~.error").innerHTML="Provincia no puede estar vacio";
		//;
	}

	if(!document.querySelector("#comarca").innerHTML){
		document.querySelector("#comarca~.error").innerHTML="Comarca no puede estar vacio";
	} else {
		document.querySelector("#comarca~.error").innerHTML="";
	}
}

function comprobarDNI(){
	var numero;
	var letraDNI;
	var letra;
	var expresion_regular_dni;
	var dni = document.querySelector("#dni").value;

	campoError = document.querySelector("#dni~.error");
	console.log(dni);
	
	expresion_regular_dni = /^\d{8}[a-zA-Z]$/;
	
	if(expresion_regular_dni.test (dni) == true){
	   numero = dni.substr(0,dni.length-1);
	   letraDNI = dni.substr(dni.length-1,1);
	   letraDNI = letraDNI.toUpperCase();
	   numero = numero % 23;
	   letra='TRWAGMYFPDXBNJZSQVHLCKET';
	   letra=letra.substring(numero,numero+1);
	   if (letra!=letraDNI) {
		campoError.innerHTML='La letra no corresponde con el DNI.';           
	   }else{
		campoError.innerHTML='';
	   }
	}else{
		campoError.innerHTML='DNI no válido.';
	}
	ponerBotonActivo();
}