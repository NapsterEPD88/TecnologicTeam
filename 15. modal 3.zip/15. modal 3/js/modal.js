window.onload=iniciar;
var hermanoAnterior=null;
var hermanoSiguiente=null;

function iniciar(){
	var imagenes=document.querySelectorAll("#galeria>img");
	for (var i=0;i<imagenes.length;i++){
		imagenes[i].onclick=function(){
			mostrarModal(this);
		}
	}
	window.onresize=ponerBoton;

	document.querySelector("#cerrar").onclick=cerrarModal;

	document.querySelector("#modal>div:first-child").onmouseover=mostrarFlecha;
	
	document.querySelector("#modal>div:first-child").onmouseout=ocultarFlecha;
	
	document.querySelector("#modal>div:first-child").onclick=function(){
		mostrarModal(hermanoAnterior);
	}

	document.querySelector("#modal>div:last-child").onmouseover=mostrarFlecha;
	
	document.querySelector("#modal>div:last-child").onmouseout=ocultarFlecha;

	document.querySelector("#modal>div:last-child").onclick=function(){
		mostrarModal(hermanoSiguiente);
	}
}



function mostrarFlecha(event){
	event.currentTarget.children[0].style.opacity="1";
}


function ocultarFlecha(event){
	event.currentTarget.children[0].style.opacity="0";
}


function mostrarModal(elemento){
	document.getElementById("texto").innerHTML=elemento.alt;
	document.getElementById("foto").src=elemento.src;
	hermanoSiguiente=elemento.nextElementSibling;
	hermanoAnterior=elemento.previousElementSibling;

	document.getElementById("modal").style.display="block"; 
	
	ponerBoton();

	//Comprobamos si tenemos que ocultar o mostrar la capa de anterior y siguiente
	var capa=document.querySelector("#modal>div:first-child");
	if (hermanoAnterior==null){
		capa.style.cursor="default";
		capa.style.visibility="hidden";	
	}	
	else{
		capa.style.cursor="pointer";
		capa.style.visibility="visible";	
	}

	capa=document.querySelector("#modal>div:last-child");
	if (hermanoSiguiente==null){
		capa.style.cursor="default";
		capa.style.visibility="hidden";		
	}
	else{
		capa.style.cursor="pointer";
		capa.style.visibility="visible";				
	}
}


function cerrarModal(event){
	document.getElementById("modal").style.display="none";
	document.getElementById("foto").src="";
}		


function ponerBoton(){
	var foto=document.getElementById("foto");
	var botonCerrar=document.querySelector("#cerrar");
	var posicionCerrar=foto.offsetWidth+foto.offsetLeft-botonCerrar.offsetWidth-8;
	botonCerrar.style.left=posicionCerrar+"px";
	botonCerrar.style.top="8px";	
}