window.onload=iniciar;
var hermanoAnterior=null;
var hermanoSiguiente=null;

function iniciar(){
	var imagenes=document.querySelectorAll("#galeria>img");
	for (var i=0;i<imagenes.length;i++){
		imagenes[i].onclick=function(){
			mostrarModal(this);
		}
	}
	window.onresize=ponerBoton;

	document.querySelector("#cerrar").onclick=cerrarModal;

	document.querySelector("#modal>div:first-child").onmouseover=mostrarFlechaI;
	document.querySelector("#modal>div:first-child").onmouseout=ocultarFlecha;
	document.querySelector("#modal>div:last-child").onmouseover=mostrarFlechaD;
	document.querySelector("#modal>div:last-child").onmouseout=ocultarFlecha;

}

function mostrarFlechaI(event){
	if (hermanoAnterior!=null){
		event.currentTarget.children[0].style.opacity="1";
		this.style.cursor="pointer";
		this.children[0].style.cursor="pointer";
		event.currentTarget.onclick=function(){
			if (hermanoAnterior.previousElementSibling==null){
				this.onclick=null;
				this.style.cursor="default";
				this.children[0].style.opacity="0";
				this.children[0].style.cursor="default";
			}
			mostrarModal(hermanoAnterior);
		}
	}
}

function mostrarFlechaD(event){
	if (hermanoSiguiente!=null){
		event.currentTarget.children[0].style.opacity="1";
		this.style.cursor="pointer";
		this.children[0].style.cursor="pointer";		
		event.currentTarget.onclick=function(){
			if (hermanoSiguiente.nextElementSibling==null){
				this.onclick=null;
				this.style.cursor="default";
				this.children[0].style.opacity="0";
				this.children[0].style.cursor="default";
			}			
			mostrarModal(hermanoSiguiente);
		}		
	}
}

function ocultarFlecha(event){
	event.currentTarget.children[0].style.opacity="0";
}


function mostrarModal(elemento){
	document.getElementById("texto").innerHTML=elemento.alt;
	var foto=document.getElementById("foto");
	foto.src=elemento.src;
	hermanoSiguiente=elemento.nextElementSibling;
	hermanoAnterior=elemento.previousElementSibling;

	document.getElementById("modal").style.display="block"; 
	
	ponerBoton();
}


function cerrarModal(event){
	document.getElementById("modal").style.display="none";
}		


function ponerBoton(){
	var foto=document.getElementById("foto");
	var botonCerrar=document.querySelector("#cerrar");
	var posicionCerrar=foto.offsetWidth+foto.offsetLeft-botonCerrar.offsetWidth-8;
	botonCerrar.style.left=posicionCerrar+"px";
	botonCerrar.style.top="8px";	
}