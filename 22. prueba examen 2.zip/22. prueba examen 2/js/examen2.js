window.onload=iniciar;

var numCajas=0;
//var contador=0;

function iniciar(){
	document.querySelector("#grande").ondblclick=crearCajas;
}

function crearCajas(event){
if (numCajas<20){
	var caja=document.createElement("div");
	numCajas++;
	//caja.setAttribute("id",numCajas);
	caja.id=numCajas;

	var texto=document.createTextNode(numCajas);
	caja.appendChild(texto);
	
	var imagen=document.createElement("img");
	imagen.src="img/"+numCajas+".svg";
	caja.appendChild(imagen);

	caja.ondblclick=borrarCaja;
	caja.onmouseenter=mostrarImagen;
	caja.onmouseleave=ocultarImagen;

	document.querySelector("#contenedor").appendChild(caja);
}
else{
	alert("Se ha llegado al final de creación de Cajas");
}
}


function borrarCaja(event){
	var respuesta=window.confirm("¿Quieres borrar al div "+event.currentTarget.id+"?");
	if (respuesta){
		this.parentNode.removeChild(this);
	}	
}

function mostrarImagen(event){
	//this.children[0].style.display="block";
	this.querySelector("img").style.display="block";
	
	document.querySelector("#grande>img").src=this.children[0].src;
	document.querySelector("#grande>img").style.display="block";
	
	var contador=parseInt(document.querySelector("#marcador").innerHTML);
	contador+=parseInt(this.id);
	document.querySelector("#marcador").innerHTML=contador;	
}


function ocultarImagen(event){
	//this.children[0].style.display="block";
	this.querySelector("img").style.display="none";
	
	document.querySelector("#grande>img").src="";
	document.querySelector("#grande>img").style.display="none";
}


