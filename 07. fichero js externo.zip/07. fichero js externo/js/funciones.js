//Evento que ocurre al terminar de cargarse el documento
window.onload=iniciar;

//En esta función pondríamos todos los eventos 
//a las etiqueta HTML que nos interese
//en este caso, al <h1> click, mouseover y mouseout
//y a todos los p de clase rojo dobleclick
function iniciar(){
	var elemento=document.querySelector("h1");
	elemento.onclick=cambiar;
	elemento.onmouseover=activarImagen;
	elemento.onmouseout=ocultarImagen;

	elemento=document.querySelectorAll("p.rojo");
	for(var i=0;i<elemento.length;i++){
		elemento[i].ondblclick=cambiar;			
	}
}

//Aquí definimos las funciones que llamaremos según los eventos
function ocultarImagen(){
	document.querySelector("img").style.display="none";
}

function activarImagen(){
	document.querySelector("img").style.display="inline-block";
}

//El objeto event se crea al producirse un evento
//y con la propiedad currentTarget de ese objeto accedemos
//al elemento del DOM que está escuchando ese evento
function cambiar(event){
	event.currentTarget.style.border="1px solid red";
}
