window.onload=init;

function init(){
	document.forms[0].terminos.onclick=activarBotones;
	document.querySelector("input[type=submit]").onclick=validarFormulario;
}


function activarBotones(event){
	var botones=document.querySelectorAll("input[type=submit]");
	for (var i = 0; i < botones.length; i++) {
		botones[i].disabled=!(event.currentTarget.checked);
	}
}


function validarFormulario(event){
	var error=false;
	
	var campos=document.forms[0].querySelectorAll("[required]");
	
	for (var i = 0; i < campos.length; i++) {
		if (campos[i].value==""){
			error=true;
			document.querySelector("[name="+campos[i].name+"]~.error").innerHTML="El campo no puede estar vacío";
		}
	}

	if (document.forms[0].estudios.selectedIndex<1){
		error=true;
		document.forms[0].estudios.nextElementSibling.innerHTML="Debes seleccionar un nivel de estudio";
	}


	campos=document.forms[0].querySelectorAll("[pattern]");
	var expresion;
	var campoError=null;
	for (var i = 0; i < campos.length; i++) {
		expresion=new RegExp(campos[i].pattern);

		if (expresion.test(campos[i].value)==false){
			error=true;
			campoError=document.querySelector("[name="+campos[i].name+"]~.error");
			if (campoError.innerHTML==""){
				campoError.innerHTML=campos[i].title;
			}
			
		}
	}

	if (document.forms[0].pass.value!=document.forms[0].pass_2.value){
		error=true;
		campoError=document.forms[0].pass_2.nextElementSibling.nextElementSibling;
		if (campoError.innerHTML==""){
			campoError.innerHTML="Las contraseñas no coinciden";
		}	
	}
	
	if (document.forms[0].genero.value==""){
		error=true;
		console.log("Error");
	}
	/*for (var i = 0; i < campos.length; i++) {
		campos[i].checked
	}*/
	console.log(document.forms[0].aficiones);

	if (error){
		event.preventDefault();
	}
}