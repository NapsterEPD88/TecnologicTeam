window.onload=iniciar;

var crono=0;
var tiempo=0;

function iniciar(){
	document.getElementById("empezar").onclick=empezar;
	document.getElementById("empezar").ondblclick=function(){
		crono=0;
	}
	document.querySelector("#parar").onclick=parar;
}

function empezar(event){
	if (tiempo==0){
		crono=0;
		tiempo=setInterval(contar,10);
	}
	//event.currentTarget.disabled=true;

}

function parar(event){
	clearInterval(tiempo);
	tiempo=0;	
}

function contar(){
	crono++;
	var cs=crono%100;
	var seg=parseInt(crono/100)%60;
	var min=parseInt(crono/6000);
	document.querySelector("h1").innerHTML=anyadirCero(min)+":"+anyadirCero(seg)+"."+anyadirCero(cs);
}

function anyadirCero(numero){
	if (numero<10){
		return "0"+numero;
	}
	else{
		return numero;
	}
}