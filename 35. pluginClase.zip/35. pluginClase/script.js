/**
 * Mini plugin para animar las cajas haciendo un efecto "box out".
 * @author Zakaria, Juan Diego, Juan, Guillem, Miguel
 * @version 0.1
 * 
 */
window.onload = init;
function mcd(x,y){
    var resto=0;
    while (x%y!=0){
        resto=x%y;
        x=y;
        y=resto;
    }

    return y;
}


function init() {
    console.log(mcd(1000,500));
    // Recogemos el div contenedor
    var contenedorImagen = document.querySelector(".wallpaper");
    // Calculamos los numeros totales de columnas y filas
    var totalColumnas = contenedorImagen.offsetWidth / 40;
    var totalFilas = contenedorImagen.offsetHeight / 40;
    // Recogemos los datos del posicionamiento del div contendor
    var offsetWImagen = contenedorImagen.offsetWidth;
    var offsetHImagen = contenedorImagen.offsetHeight;
    // Variable de los divs celda
    var celda;


    // Selecionamos la imagen del dinero
    var imagen = document.querySelector("img").src;

    // Generamos los divs celda que contienen un pedazo de la imagen 
    for (var i = 1; i <= totalFilas; i++) {
        for (var j = 1; j <= totalColumnas; j++) {
            // Creamos el elemento div
            celda = document.createElement("div");
            // Asignamos la imagen de fondo del div (la del dinero)
            celda.style.backgroundImage = "url(" + imagen + ")";
            // Selecionamos el pedazo que queremos
            celda.style.backgroundPosition = (j * 40) + "px " + (i * 40) + "px";
            // Posicionamos los divs generados en la posicion deseada
            celda.style.left = offsetWImagen + (j * -40)+ "px";
            celda.style.top = offsetHImagen + (i * -40) + "px";
            // Añadimos la clase celda
            celda.classList.add("celda");
            // Metemos un evento mouseenter en cada celda para animarlo
            celda.onmouseenter = function(){
                animacion(offsetWImagen,offsetHImagen);
            };
            // Añadimos la celda al div contenedor
            contenedorImagen.appendChild(celda);
        }
    }
    // Ocultamos la primera imagen que es la del dinero.
    document.querySelector("img").style.display = "none";
}

function animacion(x,y) {
    // Recogemos las celdas (div con pedazo de la imagen)
    var celdas = document.querySelectorAll(".celda");
    // ecorremos las celdas
    for(var i = 0; i < celdas.length;i++){
        // Generamos un numero aleatorio para escoger la direccion hacia donde se movera
        var cuadrante = Math.floor(Math.random() * 4);
        switch (cuadrante) {
            case 0:
                {
                    // Movemos a la izquierda
                    celdas[i].style.top = Math.floor(Math.random()*800)+"px";
                    celdas[i].style.left = -40+"px";
                    break;
                }
            case 1:
                {
                    // Movemos debajo
                    celdas[i].style.top = y + "px";
                    celdas[i].style.left = Math.floor(Math.random()*800)+"px";
                    break;
                }
            case 2:
                {
                    // Movemos a la derecha
                    celdas[i].style.top = Math.floor(Math.random()*800)+"px";
                    celdas[i].style.left = x + "px";
                    break;
                }
            case 3:
                {
                    // Movemos ariba
                    celdas[i].style.top = -40+"px";
                    celdas[i].style.left = Math.floor(Math.random()*800)+"px";
                    break;
                }
        }
        // Asignamos el valor temporal de la transicion
        celdas[i].style.transition = "1s";
        // Eliminamos el evento mouseenter de la celda
        celdas[i].onmouseenter = null;
    }
    
    
}
