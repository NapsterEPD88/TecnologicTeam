window.onload=iniciar;
//creamos el array con los nombres de las imágenes 
//(presuponiendo que todas están en la misma ubicación y son del mismo tipo, en este caso, .jpg)
var textos=[];
var elementos=null; //variable donde guardaremos el array de imagenes que mostramos en el carrousel
var imagenMostrada=0; //variable para guardar la imagen mostrada


function iniciar(){
	var capa=document.querySelector("#carrousel");

	//guardamos las <img> que estan dentro de carrousel
	elementos=document.querySelectorAll("#carrousel>img");

	//añadimos la propiedad left a las <img>
	for (var i = 0; i < elementos.length; i++) {
		elementos[i].style.left=(i*100)+"%";
		textos[i]=elementos[i].alt;
	}

	//mostramos el texto de la imagenMostrada
	document.querySelector("#carrousel>p").innerHTML=textos[imagenMostrada];
	document.querySelector("#carrousel>p").style.display="block";

	//activamos un intrevalo de 6s para desplazar las fotos
	setInterval(desplazar,6000);
}


/***
* Desplazamos todas las imágenes 100% a la izquierda y comprobamos la imagen que
* está a -100 para ponerla la última (más a la derecha) y además comprobamos
* si es la imagen que se va a poner visible en la pantalla (la que tiene un valor 100%)
* y añade un evento de final de transición para mostrar el texto que lleva cada imagen 
*/	
function desplazar(){
	var pos="";
	var posicion=0;

	document.querySelector("#carrousel>p").style.display="none";

	for (var i=0;i<elementos.length;i++){
		pos=elementos[i].style.left;
		pos=pos.substring(0,pos.length-1);
		posicion=parseInt(pos);
		//Desplazamos a la última posición la imagen
		if (posicion==-100){
			elementos[i].style.visibility="hidden";
			elementos[i].style.left=((elementos.length-2)*100)+"%";
		}
		else{
			//Si es la imagen que se va a mostrar ponemos el evento de final de transición
			if (posicion==100){
				imagenMostrada=i;
				elementos[i].addEventListener("transitionend",mostrarTexto);
			}
			
			elementos[i].style.visibility="visible";
			elementos[i].style.left=(posicion-100)+"%";
		}

	}
}

/***
* Mostramos el texto de la imagen mostrada y quitamos el evento 
*/
function mostrarTexto(event){
	document.querySelector("#carrousel>p").innerHTML=textos[imagenMostrada];
	document.querySelector("#carrousel>p").style.display="block";
	event.currentTarget.removeEventListener("transitionend",mostrarTexto);
}