window.onload=init;

function init(){
	document.querySelector("#una").onmousemove=sacarCoordenadas;
	document.onclick=sacarCoordenadas2;
}


function sacarCoordenadas(event){
	var capa=event.currentTarget;
	console.log()
	capa.innerHTML="X: "+event.offsetX+"Y: "+event.offsetY;
	capa.innerHTML+="<br>X: "+event.clientX+"Y: "+event.clientY;
	capa.innerHTML+="<br>X: "+event.pageX+"Y: "+event.pageY;
	capa.innerHTML+="<br>X: "+event.screenX+"Y: "+event.screenY;
	capa.innerHTML+="<br>X: "+event.movementX+"Y: "+event.movementY;
}

function sacarCoordenadas2(event){
	document.querySelector("#dos").innerHTML="X: "+event.pageX+"Y: "+event.pageY;
}