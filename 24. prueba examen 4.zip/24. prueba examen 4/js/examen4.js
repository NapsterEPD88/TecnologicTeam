window.onload=init;
var tiempo=0;

function init(){
	window.onkeyup=comprobarTecla;
}


function comprobarTecla(event){
	var tecla=event.key.toUpperCase();

	if (tecla=="E" || tecla=="S"){
		if (tiempo==0){
			document.querySelector("p").innerHTML="Pulsa P para pausar";
			crearObjetos();
			tiempo=setInterval(crearObjetos,3000);
		}
	}
	else{
		if (tecla=="P"){
			document.querySelector("p").innerHTML="Juego pausado. Pulsa de nuevo S o E para seguir";
			clearInterval(tiempo);
			tiempo=0;
		}
	}
}

function crearObjetos(){
	//creamos el div 
	var objeto=document.createElement("div");
	//generamos un aleatorio entre 0 y 1
	var aleatorio=Math.floor(Math.random()*2);
	//egún el num.aleatorio asignamos a la capa la clase circulos o cuadrados
	if (aleatorio==0){
		objeto.classList.add("circulos");
	}
	else{
		objeto.classList.add("cuadrados");
	}
	//generamos un número aleatorio entre 1 y 5 para el tamaño de la capa
	var tamanyo=Math.floor(Math.random()*5)+1;
	objeto.style.width=tamanyo+"em";
	objeto.style.height=tamanyo+"em";

	//generamos dos aleatorios entre 0 y 94 para posicionar la capa  
	var posicionLeft=Math.floor(Math.random()*95);
	var posicionTop=Math.floor(Math.random()*95);
	objeto.style.left=posicionLeft+"%";
	objeto.style.top=posicionTop+"%";

	//controlamos el evento onclick en el objeto
	objeto.onclick=destruirObjeto;

	//añadimos la capa al body del HTML
	document.body.appendChild(objeto);
}


/**
*  Destruir objeto
*/
function destruirObjeto(event){
	this.parentElement.removeChild(this);
}