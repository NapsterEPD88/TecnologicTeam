window.onload=iniciar;
var x=0;
var y=0;

function iniciar(){
	document.onkeyup=cambiarColor;
	document.onkeydown=desplazar;
	x=document.querySelector("div").offsetLeft;
	y=document.querySelector("div").offsetTop;
}

function cambiarColor(){
	document.querySelector("div").style.backgroundColor="";
}


function desplazar(event){
	var caja=document.querySelector("div");
	var tecla=event.keyCode || event.which;

	switch (tecla){
		case 37:
			x=x-5;
			caja.style.backgroundColor="purple";
		break;
		case 38:
			y=y-5;
			caja.style.backgroundColor="red";
		break;
		case 39:
			x=x+5;
			caja.style.backgroundColor="blue";
		break;
		case 40:
			y=y+5;
			caja.style.backgroundColor="orange";
		break;
	}

	caja.style.top=y+"px";
	caja.style.left=x+"px";
}