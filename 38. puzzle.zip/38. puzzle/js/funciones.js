window.onload=algo;

function algo(){
    var imagen=null;
    for (var i=0;i<4;i++){
        imagen=document.createElement("img");
        imagen.id="pieza"+(i+1);
        imagen.src="img/pieza"+(i+1)+".png";
        imagen.style.position="absolute";
        imagen.style.left=Math.random()*(window.innerWidth-175)+"px";
        imagen.style.top=(window.innerHeight-175)+"px";
        imagen.setAttribute("draggable","true");
        imagen.addEventListener("dragstart",arrastrar);
        document.body.appendChild(imagen);
    }
    document.querySelector("#caja").ondragover=permitirSoltar;
    document.querySelector("#caja").ondrop=soltar;
}

 

function arrastrar(event){
	event.dataTransfer.setData("text",event.target.id);
}

function soltar(event) {
    event.preventDefault();

    var data = event.dataTransfer.getData("text");
    var caja=event.currentTarget;
    var x = event.clientX-caja.offsetLeft;
    var y = event.clientY-caja.offsetTop;
    var pieza=document.querySelector("#"+data);

    if ((x>=53)&&(x<=200)&&(y>=28)&&(y<=150)&&(data=="pieza1")){
        pieza.style.left="53px";
        pieza.style.top="28px";
        pieza.draggable=false;
        caja.appendChild(pieza);
    }

    if ((x>=200)&&(x<=350)&&(y>=28)&&(y<=150)&&(data=="pieza2")){
        pieza.style.left="205px";
        pieza.style.top="28px";
        pieza.setAttribute("draggable","false");
        caja.appendChild(pieza);
    }    

    //Falta el código para la pieza 3 y 4
}

function permitirSoltar(event) {
   event.preventDefault();
}

