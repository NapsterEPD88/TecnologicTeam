var preguntas=[{
	pregunta: "¿Quien soy?",
	respuestas:[
		{texto: "El profesor",correcta: false},
		{texto: "El alumno",correcta: false},
		{texto: "Dios",correcta: true}
	]
},
{
	pregunta: "¿Cómo me llamo?",
	respuestas:[
		{texto: "Juan",correcta: false},
		{texto: "Alex",correcta: true},
		{texto: "Pepe",correcta: false}
	]
},
{
	pregunta: "¿De qué equipo soy?",
	respuestas:[
		{texto: "FCBarcelona",correcta: false},
		{texto: "Real Madrid CF",correcta: true},
		{texto: "Villarreal CF",correcta: false}
	]
}
]

window.onload=init;

function init(){
	var aleatorio=Math.floor(Math.random())*preguntas.length;
	console.log(preguntas[aleatorio]);
}