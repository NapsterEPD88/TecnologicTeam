window.onload=iniciar;

function iniciar(){
	var objetos=document.querySelectorAll("div:not([id=informacion])");
	for (var i = 0; i < objetos.length; i++) {
		objetos[i].onmouseover=ponerRecuadro;
		objetos[i].onmouseout=quitarRecuadro;
		objetos[i].onmousemove=ponerCoordenadas;
		objetos[i].onclick=reconocerCapa;
	}
}


function ponerRecuadro(event){
	event.currentTarget.classList.add("activado");
}

function quitarRecuadro(event){
	/**** equivale a lo mismo con this = event.currentTarget ***
	event.currentTarget.style.outline="none";
	event.currentTarget.innerHTML=""; */
	this.classList.remove("activado");
	this.innerHTML="";

}

function ponerCoordenadas(event){
	event.currentTarget.innerHTML="x:"+event.offsetX+"<br>y:"+event.offsetY;
}

function reconocerCapa(event){
	document.querySelector("#informacion").innerHTML="Has pulsado al div "+this.id;
}