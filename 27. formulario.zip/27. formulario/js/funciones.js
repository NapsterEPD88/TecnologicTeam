window.onload=init;
var casillasMarcadas=0;

function init(){
	document.forms[0].enviar.onclick=mostrarDatos;
	var aficiones=document.forms[0].aficiones;

	for (var i = 0; i < aficiones.length; i++) {
		aficiones[i].onclick=comprobarAficiones;
	}
}

function mostrarDatos(event){
	console.log(document.forms[0].codigo.value);
	console.log(document.forms[0].aficiones.length);
	event.preventDefault();
}

function comprobarAficiones(event){
	if(event.currentTarget.checked){
		casillasMarcadas++;
	}
	else{
		casillasMarcadas--;
	}


	if (casillasMarcadas==3){
		var af=document.forms[0].querySelectorAll("[name=aficiones]:not(:checked)");
		for (var i = 0; i < af.length; i++) {
			af[i].disabled=true;
		}
	}
	else{
		var af=document.forms[0].querySelectorAll("[name=aficiones]:disabled");
		for (var i = 0; i < af.length; i++) {
			af[i].disabled=false;
		}
	}
}