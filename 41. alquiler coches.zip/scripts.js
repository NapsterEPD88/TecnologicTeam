window.onload=init;
var bandera1=false;
var bandera2=true;
var bandera3=true;
var coches = 	[{marca:"Audi",modelo:"A3 Sedán",tipo:"berlina"},
				{marca:"BMW",modelo:"Serie 2 Cabrio",tipo:"descapotable"},
				{marca:"Mercedes",modelo:"Clase V",tipo:"monovolumen"},
				{marca:"FIAT",modelo:"124 Speeder",tipo:"deportivo"},
				{marca:"Toyota",modelo:"GT86",tipo:"deportivo"}];

function init() {
	rellenarFechas();
	document.forms[0].tipocoche.onclick = comprobarCoche;
	document.forms[0].inicio.onchange = comprobarInicio;
	document.forms[0].inicio.onchange = comprobarDiferencia;
	document.forms[0].fin.onchange = comprobarDiferencia;
	document.forms[0].boton.onclick = mostrarCoches;
}

function rellenarFechas(){
	var ahora = new Date();
	ahora.setMinutes(ahora.getMinutes()+150); //120 para poner en hora + 30 de margen
	var minima = new Date(ahora);
	minima.setDate(minima.getDate()+1);
	var string_ahora = ahora.toISOString();
	var string1 =string_ahora.substr(0,(string_ahora.length-8));
	var string_fin = minima.toISOString();
	var string2 =string_fin.substr(0,(string_fin.length-8));
	//console.log(string1);
	document.forms[0].inicio.value = string1;
	document.forms[0].fin.value = string2;
}

function comprobarCoche(event){
	if(event.currentTarget.value!=""){
		console.log("Tipo de coche correcto");
		bandera1=true;
	}
	else{
		console.log("Seleccione un coche");
		bandera1=false;
	}
	activarBoton();
}

function comprobarInicio(event){
	var inicio = new Date(event.currentTarget.value);
	var hoy = new Date();
	console.log(inicio);
	console.log(hoy);
	var diferencia = inicio-hoy;
	if(diferencia>0){
		console.log("Fecha de inicio correcta");
		bandera2=true;
	}
	else{
		console.log("Fecha de inicio incorrecta");
		bandera2=false;
	}
	activarBoton();
}

function comprobarDiferencia(event){
	var inicio = new Date(document.forms[0].inicio.value);
	var final = new Date(document.forms[0].fin.value);
	var diferencia = (final - inicio)/1000/60/60;
	if(diferencia>=24){
		console.log("Fechas validas");
		bandera3=true;
	}
	else{
		console.log("Fechas incorrectas");
		bandera3=false;
	}
	activarBoton();
}
function activarBoton(){
	if(bandera1&&bandera2&&bandera3)
		document.forms[0].boton.disabled=false;
	else
		document.forms[0].boton.disabled=true;
}

function mostrarCoches(event){
	document.querySelector("#coches").innerHTML="";
	var seleccionado = document.forms[0].tipocoche.value;
	var parrafo;
	for(var i=0; i<coches.length; i++){
		if(seleccionado==coches[i].tipo){
			parrafo = document.createElement("p");
			parrafo.innerHTML=
					"<strong>Marca: </strong>"+coches[i].marca+
					"<br><strong>Modelo: </strong>"+coches[i].modelo;
					//+"<img src='imgs/"+coches[i].imagen+"'>";
			document.querySelector("#coches").appendChild(parrafo);
		}
	}
	event.preventDefault();
}